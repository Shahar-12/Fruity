//package com.shahar.fruity;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.net.URL;
//import java.net.URLConnection;
//
//public class FruityviceAPI {
//    private Fruit[] fruits;
//    private int size;
//    FruityviceAPI() throws IOException {
//        fruits=new Fruit[5];
//        String CONNECT_API_URL = "https://www.fruityvice.com/api/fruit/all";
//
//        String jsonResponse = getJsonResponse(CONNECT_API_URL);
//        printFruitInfo(jsonResponse);
//    }
//
//
//    private String getJsonResponse(String apiUrl) throws IOException {
//        URL url = new URL(apiUrl);
//        URLConnection urlc = url.openConnection();
//
//
//        BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
//        StringBuilder response = new StringBuilder();
//        String inputLine;
//
//        while ((inputLine = br.readLine()) != null) {
//            response.append(inputLine);
//        }
//
//        br.close();
//
//        return response.toString();
//    }
//
//    private void printFruitInfo(String jsonResponse) {
//        // Remove leading '[' and trailing ']'
//        String jsonArray = jsonResponse.substring(1, jsonResponse.length() - 1);
//
//        // Extract information about each fruit
//        String[] fruits = jsonArray.split("\\},\\{");
//        for (String fruit : fruits) {
//            String[] attributes = fruit.replaceAll("[{}\"]", "").split(",");
//            String name = "";
//            double sugar = 0;
//            double protein = 0;
//            double calories = 0;
//
//            for (String attribute : attributes) {
//                String[] keyValue = attribute.split(":");
//                String key = keyValue[0].trim();
//                String value = keyValue[1].trim();
//
//                switch (key) {
//                    case "name":
//                        name = value;
//                        break;
//                    case "sugar":
//                        sugar = Double.parseDouble(value);
//                        break;
//                    case "protein":
//                        protein = Double.parseDouble(value);
//                        break;
//                    case "calories":
//                        calories = Double.parseDouble(value);
//                        break;
//                }
//            }
//
//            // Print name, sugar, protein, and calories for each fruit
//            create_fruits(name,sugar,protein,calories);
//        }
//    }
//    private void create_fruits(String name,double sugar,double protein,double calories){
//        if(size<5) {
//            Fruit fruit = new Fruit(name, protein, calories);
//            fruits[size] = fruit;
//            size++;
//        }
//    }
//    public Fruit[] get_fruits(){
//        return fruits;
//    }
//}
