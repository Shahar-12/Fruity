package com.shahar.fruity;

public class Fruit {
    private String name;
    private double sugar;
    private double protein;
    private double calories;
    public Fruit(String name,double sugar,double protein,double calories){
        this.name=name;
        this.sugar=sugar;
        this.protein=protein;
        this.calories=calories;
    }

    public Fruit(Fruit fruit) {
        this.name=fruit.name;
        this.sugar=fruit.sugar;
        this.protein=fruit.protein;
        this.calories=fruit.calories;
    }

    public String get_name(){
        return name;
    }
    public double get_protein(){
        return protein;
    }
    public double get_calories(){
        return calories;
    }
    public double get_sugar(){return sugar;}
}
