package com.shahar.fruity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.appsflyer.AFInAppEventParameterName;
import com.appsflyer.AppsFlyerConversionListener;
import com.appsflyer.AppsFlyerLib;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.LoginException;


public class MainActivity extends AppCompatActivity {
    String api="https://www.fruityvice.com/api/fruit/all";
    ArrayList<Fruit> allfruitslist;

    private TextView sortByTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        allfruitslist=new ArrayList<>();
        getData();
        setContentView(R.layout.activity_main);



        sortByTextView = findViewById(R.id.Sortby);

//        if (allfruitslist.size()==0) {
//            text1.append("k");
//        }
        Button sugarButton = findViewById(R.id.Sugar);
        Button proteinButton = findViewById(R.id.Protein);
        Button caloriesButton = findViewById(R.id.Calories);
        Button resetButton = findViewById(R.id.Reset);
        registerConversionDataListener();

        sugarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ArrayList<Fruit> sortsugar = new ArrayList<>(allfruitslist.size());
                for (Fruit fruit : allfruitslist) {
                    // Assuming Fruit has a copy constructor
                    sortsugar.add(new Fruit(fruit));
                }

                // Sort the new list by protein value
                sortsugar.sort(new Comparator<Fruit>() {
                    @Override
                    public int compare(Fruit o1, Fruit o2) {
                        return Double.compare(o1.get_sugar(), o2.get_sugar());
                    }
                });
                createScroll(sortsugar,1,0,0);

                sortBy("Sort by: SUGAR");
                logButtonClickEvent("Sugar");
            }
        });

        proteinButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Create a deep copy of allfruitslist
                ArrayList<Fruit> sortprotein = new ArrayList<>(allfruitslist.size());
                for (Fruit fruit : allfruitslist) {
                    // Assuming Fruit has a copy constructor
                    sortprotein.add(new Fruit(fruit));
                }

                // Sort the new list by protein value
                sortprotein.sort(new Comparator<Fruit>() {
                    @Override
                    public int compare(Fruit o1, Fruit o2) {
                        return Double.compare(o1.get_protein(), o2.get_protein());
                    }
                });

                createScroll(sortprotein,0,1,0);
                sortBy("Sort by: PROTEIN");
                logButtonClickEvent("Protein");
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                createScroll(allfruitslist,0,0,0);
                sortBy("Sort by: NONE");
                logButtonClickEvent("None");
            }
        });


        caloriesButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ArrayList<Fruit> sortcalories = new ArrayList<>(allfruitslist.size());
                for (Fruit fruit : allfruitslist) {
                    // Assuming Fruit has a copy constructor
                    sortcalories.add(new Fruit(fruit));
                }

                // Sort the new list by protein value
                sortcalories.sort(new Comparator<Fruit>() {
                    @Override
                    public int compare(Fruit o1, Fruit o2) {
                        return Double.compare(o1.get_calories(), o2.get_calories());
                    }
                });
                createScroll(sortcalories,0,0,1);
                sortBy("Sort by: CALORIES");
                logButtonClickEvent("Calories");
            }
        });
    }
    private void logButtonClickEvent(String buttonType) {
        Map<String, Object> eventValues = new HashMap<>();
        eventValues.put("BUTTON TYPE", buttonType);

        AppsFlyerLib.getInstance().logEvent(getApplicationContext(),
                "Button Clicked", eventValues);
    }
    private void registerConversionDataListener() {
        AppsFlyerConversionListener conversionListener = new AppsFlyerConversionListener() {
            @Override
            public void onConversionDataSuccess(Map<String, Object> conversionData) {
                for (String attrName : conversionData.keySet()) {
                    Log.d("ConversionData", "Attribute: " + attrName + " = " +
                            conversionData.get(attrName));
                }
            }

            @Override
            public void onConversionDataFail(String errorMessage) {
                Log.e("ConversionData", "Failed to get conversion data: " + errorMessage);
            }

            @Override
            public void onAppOpenAttribution(Map<String, String> attributionData) {
                // Handle deep linking attribution data here
            }

            @Override
            public void onAttributionFailure(String errorMessage) {
                Log.e("Attribution", "Failed to get attribution data: " + errorMessage);
            }
        };

        AppsFlyerLib.getInstance().init("fb8Q2zo9PAxeMYGSwXo6Bo", conversionListener,
                getApplicationContext());
        AppsFlyerLib.getInstance().start(this);
    }


    private void sortBy(String sortByType) {
        sortByTextView.setText(sortByType);

    }
    private void createScroll(ArrayList<Fruit> fruit_arr,int s,int p,int c) {
        LinearLayout scrollLinearLayout = findViewById(R.id.scrollLinearLayout);
        scrollLinearLayout.removeAllViews(); // Clear existing TextViews

        for (int i = 0; i < fruit_arr.size() ; i++) {
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            layoutParams.setMargins(0, 0, 35, 16); // Add bottom margin for spacing
            textView.setLayoutParams(layoutParams);
            if(p==0&s==0&c==0) {
                textView.setText(fruit_arr.get(i).get_name() + "\n" +
                        "Protein: " + fruit_arr.get(i).get_protein() + "\n" +
                        "Calories: " + fruit_arr.get(i).get_calories() + "\n" +
                        "Sugar: " + fruit_arr.get(i).get_sugar());
            }
            else if(p==1){
                SpannableString spannableString = new SpannableString(
                        fruit_arr.get(i).get_name() + "\n" +
                                "Protein: " + fruit_arr.get(i).get_protein() + "\n" +
                                "Calories: " + fruit_arr.get(i).get_calories() + "\n" +
                                "Sugar: " + fruit_arr.get(i).get_sugar());

                // Apply bold style to "Protein" and its value
                int startIndex = spannableString.toString().indexOf("Protein:");
                int endIndex = startIndex + "Protein:".length();
                spannableString.setSpan(new StyleSpan(Typeface.BOLD), startIndex, endIndex,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                textView.setText(spannableString);
            }
            else if(c==1){
                SpannableString spannableString = new SpannableString(
                         fruit_arr.get(i).get_name() + "\n" +
                                "Protein: " + fruit_arr.get(i).get_protein() + "\n" +
                                "Calories: " + fruit_arr.get(i).get_calories() + "\n" +
                                "Sugar: " + fruit_arr.get(i).get_sugar());

                // Apply bold style to "Protein" and its value
                int startIndex = spannableString.toString().indexOf("Calories:");
                int endIndex = startIndex + "Calories:".length();
                spannableString.setSpan(new StyleSpan(Typeface.BOLD), startIndex, endIndex,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                textView.setText(spannableString);

            }
            else if(s==1){
                SpannableString spannableString = new SpannableString(
                         fruit_arr.get(i).get_name() + "\n" +
                                "Protein: " + fruit_arr.get(i).get_protein() + "\n" +
                                "Calories: " + fruit_arr.get(i).get_calories() + "\n" +
                                "Sugar: " + fruit_arr.get(i).get_sugar());

                // Apply bold style to "Protein" and its value
                int startIndex = spannableString.toString().indexOf("Sugar:");
                int endIndex = startIndex + "Sugar:".length();
                spannableString.setSpan(new StyleSpan(Typeface.BOLD), startIndex, endIndex,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                textView.setText(spannableString);
            }
            textView.setBackgroundResource(R.drawable.pictext2);
            textView.setTextSize(20);
            scrollLinearLayout.addView(textView);
        }
    }

    private void getData() {

        RequestQueue queue = Volley.newRequestQueue(this);

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        try {
                            JSONArray array=new JSONArray(response);
                            for(int i=0;i<array.length();i++){
                                JSONObject singleobject=array.getJSONObject(i);
                                JSONObject nutritionObject = singleobject.getJSONObject("nutritions");
                                Fruit singlefruit=new Fruit(
                                        singleobject.getString("name"),
                                        nutritionObject.getDouble("sugar"),
                                        nutritionObject.getDouble("protein"),
                                        nutritionObject.getDouble("calories")
                                );
                                allfruitslist.add(singlefruit);
                            }
                            createScroll(allfruitslist,0,0,0);
                            Log.e("api", "onResponse: "+allfruitslist.size() );
                        } catch (JSONException e) {
                            throw new RuntimeException(e);

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("api","on error");

            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);
    }
}
